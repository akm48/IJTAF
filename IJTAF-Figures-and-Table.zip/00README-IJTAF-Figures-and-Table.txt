00README-IJTAF-Figures-and-Table.txt

(c) All rights are reserved by Yohji Akama (yoji.akama.e8@tohoku.ac.jp), 8 August 2023
      Programs and datasets to produce the figures and the table of 
[1]      Yohji Akama, Correlation matrix of equi-correlated normal population: fluctuation of the largest eigenvalue, 
      scaling of the bulk eigenvalues, and stock market, International Journal of Theoretical and Applied Finance, 
      https://doi.org/10.1142/S0219024923500061 (Accepted on 7 Mar '23).



The images of [1] are in

    IMAGEDIR=1-factor-model/Image/

The table of [1] is in

    (PROGRAMDIR)/Figure1_Table1/IJTAF_Tbl1.csv
    
where the programs that produce the images and the table of [1] are in

    PROGRAMDIR=1-factor-model/Program/

The data the programs use are in 

    DATADIR=IJTAF/Presentation/Program/GetSymbols/

The datasets were downloaded on 2022-08-24/2022-09-02. 
Some of csv files of companies are nolonger downloadable, beause the companies have disappeared.


(DATADIR)/download.R
The function download(LIST,START,END,PREFIX) downloads the daily stock price of the quotes in LIST from START to END in 
(PREFIX)--(START)-(END)/(QUOTE)--(START)-(END).csv.
Here
LIST is a list of quotes,
START is the starting date such as 20xx-xx-xx,
END is the ending date such as 20xx-xx-xx, and
PREFIX is like (NUMBER of QUOTES)-(GICS-sector).

(DATADIR)/19-CommServ--2012-01-01-2022-01-01  # Downloaded on 2022-09-02
(DATADIR)/52-ConsumerDiscretionary--2012-01-01-2022-01-01  # Downloaded on 2022-09-02
(DATADIR)/23-ConsumerStaples--2012-01-01-2022-01-01  # Downloaded on 2022-09-02
(DATADIR)/16-Energy--2012-01-01-2022-01-01  # Downloaded on 2022-09-02
(DATADIR)/63-Financials--2012-01-01-2022-01-01  # Downloaded on 2022-09-02
(DATADIR)/47-HealthCare--2012-01-01-2022-01-01  # Downloaded on 2022-09-02
(DATADIR)/65-Industrials--2012-01-01-2022-01-01  # Downloaded on 2022-09-02
(DATADIR)/62-InformationTechnology--2012-01-01-2022-01-01  # Downloaded on 2022-09-02
(DATADIR)/24-Materials--2012-01-01-2022-01-01  # Downloaded on 2022-09-02
(DATADIR)/30-RealEstate--2012-01-01-2022-01-01  # Downloaded on 2022-08-24
(DATADIR)/28-Utilities--2012-01-01-2022-01-01  # Downloaded on 2022-09-02
(DATADIR)/429-SP500--2012-01-01-2022-01-01  # Downloaded on 2022-08-24/2022-09-02



(DATADIR)/Lists_of_SP500_symbols.R
The lists of quotes for 2012-01-01/2022-01-01 as is 2022-08-24/2022-09-02.
Some companies have disappeared.


(PROGRAMDIR)/Figure1_Table1/mk_IJTAF_429-SP500.R
Creates the directory for the totality of sp500.


(PROGRAMDIR)/Figure1_Table1/mk_IJTAF_Fig1_Tbl1.R
This R-file makes Table 1 and Figure 1 of
a(LIST, NUM) draws the time series of equi-correlation coefficients of returns of a given list of companies, 2012-01-01/2022-01-01
read the csv files rowname[NUM]--2012-01-01-2021-12-31/company--2012-01-01-2022-01-01.csv from DATADIR, and then draws the time series of equi-correlation coefficients of returns of a given list of companies, 2012-01-01/2022-01-01.

The function a(LIST, NUM)  overlays a red horizontal line at height the largest eigenvalue lambda_1(C) divided by the order N where C is the financial correlation matrix of LIST.
The png is written in IMAGEDIR.

a() prints the following to the standard output:
GK, c=N/T, lambda_1(C)/N, DECO estimate of rho, N, GICS, T, Period, GJR GARCH-DECO computation time, and the time to compute lambda_1(C)/N.
a() also computes  Table 1 of [1], GICS(and the TOTAL)  N/T, lambda_1(C)/N, N, and DECO estimate of rho, in

(PROGRAMDIR)/Figure1_Table1/IJTAF_Tbl1.csv




(PROGRAMDIR)/Figure2/mk_IJTAF_Figure2.R
This R-file makes Figure 2 of [1]
They are the heat maps of Pearson correlation matrices of the stock returns of the 12 datasets of Table 1 of [1].

The heatmaps are saved in (IMAGEDIR)/Figure2/offline_heatmap--NUM-GICS--START-END.png.
The datasets are (DATADIR)/NUM-SP500--START-END/company--START-END.csv. 




(PROGRAMDIR)/Figure3/mk_IJTAF_Fig3.R
This R-file makes Figure 3 of [1]. It is the regression analysis of the time-average of rho by lambda_1(C)/N.
the picture saved in ../../Image/Figure3/av_rholev_plot.png.


--------------------------------------------------------------------------------------------------------------
REQUIREMENTS

#########################################################################################################################
#
#
#	download.R
#
#
#########################################################################################################################

#Quantitative Financial Modelling Framework
#Specify, build, trade, and analyse quantitative financial trading strategies.(https://www.rdocumentation.org/packages/quantmod/versions/0.4.20)
quantmod

#eXtensible Time Series
#Provide for uniform handling of R's different time-based data classes by extending zoo, maximizing native format information preservation and allowing for user level customization and extension, while simplifying cross-class interoperability.(https://www.rdocumentation.org/packages/xts/versions/0.12.1)
xts

#########################################################################################################################
#
#
#	mk_IJTAF_Fig1_Tbl1.R
#
#
#########################################################################################################################

#Quantitative Financial Modelling Framework
#Specify, build, trade, and analyse quantitative financial trading strategies.(https://www.rdocumentation.org/packages/quantmod/versions/0.4.20)
quantmod


#stringr
#
#Overview
#
#Strings are not glamorous, high-profile components of R, but they do play a big role in many data cleaning and preparation tasks. The stringr package provides a cohesive set of functions designed to make working with strings as easy as possible. If you’re not familiar with strings, the best place to start is the chapter on strings in R for Data Science.
#
#stringr is built on top of stringi, which uses the ICU C library to provide fast, correct implementations of common string manipulations. stringr focusses on the most important and commonly used string manipulation functions whereas stringi provides a comprehensive set covering almost anything you can imagine. If you find that stringr is missing a function that you need, try looking in stringi. Both packages share similar conventions, so once you’ve mastered stringr, you should find stringi similarly easy to use.
#(https://rdocumentation.org/packages/stringr/versions/1.5.0)
stringr



#eXtensible Time Series
#Provide for uniform handling of R's different time-based data classes by extending zoo, maximizing native format information preservation and allowing for user level customization and extension, while simplifying cross-class interoperability.(https://www.rdocumentation.org/packages/xts/versions/0.12.1)
xts


#DCC Models with GARCH-MIDAS Specifications in the Univariate Step
#Estimates a variety of Dynamic Conditional Correlation (DCC) models. More in detail, the 'dccmidas' package allows the estimation of the corrected DCC (cDCC) of Aielli (2013) , the DCC-MIDAS of Colacito et al. (2011) , the Asymmetric DCC of Cappiello et al. , and the Dynamic Equicorrelation (DECO) of Engle and Kelly (2012) . 'dccmidas' offers the possibility of including standard GARCH , GARCH-MIDAS and Double Asymmetric GARCH-MIDAS models in the univariate estimation. Finally, the package calculates also the var-cov matrix under two non-parametric models: the Moving Covariance and the RiskMetrics specifications.(https://www.rdocumentation.org/packages/dccmidas/versions/0.1.0)
dccmidas


#Univariate GARCH-MIDAS, Double-Asymmetric GARCH-MIDAS and MEM-MIDAS
#Adds the MIxing-Data Sampling (MIDAS, Ghysels et al. (2007) ) components to a variety of GARCH and MEM (Engle (2002) ) models, with the aim of predicting the volatility with additional low-frequency (that is, MIDAS) terms. The estimation takes place through simple functions, which provide in-sample and (if present) and out-of-sample evaluations. 'rumidas' also offers a summary tool, which synthesizes the main information of the estimated model. There is also the possibility of generating one-step-ahead and multi-step-ahead forecasts. (https://www.rdocumentation.org/packages/rumidas/versions/0.1.1)
rumidas


#########################################################################################################################
#
#
#	mk_IJTAF_Fig2.R
#
#
#########################################################################################################################
# pheatmap: A function to draw clustered heatmaps. (https://www.rdocumentation.org/packages/pheatmap/versions/1.0.12/topics/pheatmap)
pheatmap




#################################################################################################
#
#    How to execute
#
#################################################################################################
-------------------------------------------------------------------------------------------------
Change to directory (PROGRAMDIR)/Figure1_Table1
Then, invoke R
If you want to see the time series of Figure 1 and generate Tbl1, then  enter

source(file='mk_IJTAF_429-SP500.R').

in the R prompt. After that, enter

source(file='mk_IJTAF_Fig1_Tbl1.R')

in the R prompt. If you want to save the time series of Figure 1 and generate Tbl1, then rewrite 'save=FALSE' to 'save=TRUE' in the definition of a function a(), and then enter

source(file='mk_IJTAF_Fig1_Tbl1.R')

You will find the images in  (IMAGEDIR)/Figure1/.
-------------------------------------------------------
Change to directory (PROGRAMDIR)/Figure2
Then, invoke R

source(file='mk_IJTAF_Fig2.R')

in the R prompt. You will find the images in  (IMAGEDIR)/Figure2/.
-------------------------------------------------------
Change to directory (PROGRAMDIR)/Figure3
Then, invoke R

source(file='mk_IJTAF_Fig3.R')

in the R prompt. You will find the images in  (IMAGEDIR)/Figure3/.


# The end of 00README-IJTAF-zip4github.txt
