####################################################################################################################
#
# download.R
#
#  (c) All rights are reserved by Yohji Akama (yoji.akama.e8@tohoku.ac.jp), 8 August 02023.
#      Supplimentary material of 
#      Yohji Akama, Correlation matrix of equi-correlated normal population: fluctuation of the largest eigenvalue, 
#      scaling of the bulk eigenvalues, and stock market, International Journal of Theoretical and Applied Finance, 
#      https://doi.org/10.1142/S0219024923500061 (Accepted on 7 Mar '23).
#
#
# The function download(LIST,START,END,PREFIX) downloads the daily stock price of the quotes in LIST from START to END in 
# (PREFIX)--(START)-(END)/(QUOTE)--(START)-(END).csv.
#
# LIST is a list of quotes,
# START is the starting date such as 20xx-xx-xx,
# END is the ending date such as 20xx-xx-xx, and
# PREFIX is like (NUMBER of QUOTES)-(GICS-sector).
#
#
# Unrelocatable
#
# Written by Yohji Akama on 28 Aug. 2022.
# Revised by Yohji Akama on 5 May 2023.
# Deleted comments written in Japanese on 8 Aug. 2023.
#
####################################################################################################################
#
#
#
#
# Download the daily stock price of the following 11 Energy companies of S&P500
#
#  The daily stock price of the following 212 companies of S&P500. The order is by founded year.
#
# We omitted quotes that are founded after 2012-01-01.

#Quantitative Financial Modelling Framework
#Specify, build, trade, and analyse quantitative financial trading strategies.(https://www.rdocumentation.org/packages/quantmod/versions/0.4.20)
library(quantmod)


#eXtensible Time Series
#Provide for uniform handling of R's different time-based data classes by extending zoo, maximizing native format information preservation and allowing for user level customization and extension, while simplifying cross-class interoperability.(https://www.rdocumentation.org/packages/xts/versions/0.12.1)
require(xts)

#xts will call zoo.
#zoo (version 1.8-10)
#S3 Infrastructure for Regular and Irregular Time Series (Z's Ordered Observations)
#An S3 class with methods for totally ordered indexed observations. It is particularly aimed at irregular time series of numeric vectors/matrices and factors. zoo's key design goals are independence of a particular index/date/time class and consistency with ts and base R by providing methods to extend standard generics.
#(https://www.rdocumentation.org/packages/zoo/versions/1.8-10)
#require(zoo)

# Do download the csv files of a given list of companies, start, end and the prefix of the filename
download <- function(s,start, end, prefix){
  period<-paste(start,"-",end,sep="")#"2005-01-04-2013-12-30"
  directory<-paste(prefix,"--", period, sep="")

  if (file.exists(directory)){
    cat("The directory already exists.\n")
  } else {
    dir.create(directory, showWarnings = TRUE, recursive = FALSE, mode = "0777")
  }

  for (i in 1:length(s)){
    savefile=paste(directory,"/",s[i],"--", period, ".csv",sep="")
#quantmod (version 0.4.20)
#getSymbols: Load and Manage Data from Multiple Sources
# Functions to load and manage ‘Symbols’ in specified environment.
#     Used by ‘specifyModel’ to retrieve symbols specified in first
#    step of modelling procedure.  Not a true S3 method, but methods
#     for different data sources follow an S3-like naming convention.
#     Additional methods can be added by simply adhering to the
#     convention.
#
#     Current ‘src’ methods available are: yahoo, google, MySQL, FRED,
#     csv, RData, oanda, and av.
#
#     Data is loaded silently _without_ user assignment by default.
#(https://www.rdocumentation.org/packages/quantmod/versions/0.4.20/topics/getSymbols)
    dat0 = getSymbols(s[i], env=xts,src="yahoo", from=start,verbose=TRUE, to=end, auto.assign = F, warnings = FALSE, symbol.lookup = F)
    write.zoo(dat0, file=savefile, sep=",")
  }
}
# end of the definition of function download()


# End of download.R
